export { default as authRoutes } from "./auth.route";
export { default as profileRoutes } from "./profile.route";
export { default as courseRoutes } from "./course.route";
export { default as forumRoutes } from "./forum.route";
