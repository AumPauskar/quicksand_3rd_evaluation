class OrganizationService {}

export default new OrganizationService();
