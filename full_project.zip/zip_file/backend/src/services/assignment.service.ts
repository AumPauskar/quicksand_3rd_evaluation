class AssignmentService {}

export default new AssignmentService();
