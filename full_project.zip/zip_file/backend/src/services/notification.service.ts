class NotificationsService {}

export default new NotificationsService();
