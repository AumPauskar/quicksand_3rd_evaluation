const cashifyApi = "https://cashify-node-server.onrender.com"


export { cashifyApi }