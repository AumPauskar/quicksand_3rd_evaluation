const baseUrl = "https://course-app-backend-whjt.onrender.com"



export { baseUrl }