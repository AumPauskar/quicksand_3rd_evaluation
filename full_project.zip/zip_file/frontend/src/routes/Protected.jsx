import React from 'react'

const Protected = () => {
  return (
    <div>
      
    </div>
  )
}

export default Protected
