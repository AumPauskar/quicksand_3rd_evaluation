import React from 'react'

function Navbar() {



    console.log("its navbar")
  return (
    <div>
      Navbar
    </div>
  )
}

export default Navbar
